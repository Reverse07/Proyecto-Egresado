
package Dao;

import Modelo.Egresado;
import java.util.List;

public interface EgresadoDAO {
    
    // Agrega un nuevo egresado
    void agregarEgresado(Egresado egresado);

    // Actualiza los datos de un egresado existente
    void actualizarEgresado(Egresado egresado);

    // Elimina un egresado por su ID
    void eliminarEgresado(int estudiante_id);

    // Retorna todos los egresados
    List<Egresado> listarEgresados();

    // Busca un egresado por su DNI
    Egresado buscarPorDNI(String dni);
}