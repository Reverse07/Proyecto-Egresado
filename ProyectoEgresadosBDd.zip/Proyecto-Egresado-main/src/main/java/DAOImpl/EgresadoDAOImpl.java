
package DAOImpl;

public class EgresadoDAOImpl {
    
}
